import os
import json
import time
from datetime import datetime
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class ForumEngine:
    def __init__(self, query_agent, media_agent, insight_agent, report_agent):
        self.query_agent = query_agent
        self.media_agent = media_agent
        self.insight_agent = insight_agent
        self.report_agent = report_agent
        self.name = "论坛协调引擎"
        self.role = "负责协调多个金融分析代理，促进它们之间的信息共享和协作分析"
        self.max_rounds = int(os.getenv('MAX_ANALYSIS_DEPTH', 3))
        self.conversation_history = []
    
    def process_query(self, user_query, user_profile=None):
        """
        处理用户查询，协调各Agent工作
        参数:
            user_query: 用户查询内容
            user_profile: 用户画像
        返回:
            综合分析结果和报告
        """
        if user_profile is None:
            user_profile = {
                "risk_profile": "balanced",
                "investment_horizon": "medium",
                "age": 35,
                "investment_experience": "intermediate"
            }
        
        # 记录开始时间
        start_time = time.time()
        
        # 步骤1: 调用Query Agent获取基础数据
        print(f"[协调引擎] 开始调用 {self.query_agent.name} 获取市场数据...")
        query_data = self.query_agent.process_request(user_query)
        self._add_to_history("QueryAgent", "数据获取", query_data)
        
        # 步骤2: 调用Media Agent进行数据分析和可视化
        print(f"[协调引擎] 开始调用 {self.media_agent.name} 进行数据分析...")
        
        # 确定分析类型
        analysis_type = self._determine_analysis_type(query_data)
        analysis_results = self.media_agent.analyze_data(query_data, analysis_type)
        self._add_to_history("MediaAgent", "数据分析", analysis_results)
        
        # 步骤3: 启动多轮论坛讨论和深度分析
        print(f"[协调引擎] 开始多轮论坛讨论，深度分析市场情况...")
        forum_results = self._conduct_forum_discussion(query_data, analysis_results, user_profile)
        
        # 步骤4: 调用Insight Agent生成深度洞察和投资建议
        print(f"[协调引擎] 调用 {self.insight_agent.name} 生成投资洞察...")
        insights = self.insight_agent.generate_insights(
            {**query_data, **analysis_results}, 
            user_profile
        )
        self._add_to_history("InsightAgent", "投资洞察", insights)
        
        # 结合论坛讨论结果
        if forum_results:
            insights["forum_discussion"] = forum_results
        
        # 步骤5: 调用Report Agent生成最终报告
        print(f"[协调引擎] 调用 {self.report_agent.name} 生成分析报告...")
        final_report = self.report_agent.generate_report(
            query_data, 
            analysis_results, 
            insights, 
            user_profile
        )
        
        # 计算处理时间
        processing_time = time.time() - start_time
        
        # 返回综合结果
        return {
            "query": user_query,
            "user_profile": user_profile,
            "query_data": query_data,
            "analysis_results": analysis_results,
            "insights": insights,
            "report": final_report["formatted_report"],
            "report_path": final_report["report_path"],
            "html_report_path": final_report["html_report_path"],
            "processing_time": round(processing_time, 2),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    
    def _determine_analysis_type(self, query_data):
        """
        根据查询数据确定分析类型
        参数:
            query_data: 查询数据
        返回:
            分析类型
        """
        if isinstance(query_data, dict):
            if "ticker" in query_data:
                return "stock_chart"
            elif "market_indexes" in query_data:
                return "market_trend"
            elif "sector_performance" in query_data:
                return "sector_comparison"
            elif "asset_allocation" in query_data:
                return "portfolio_allocation"
        
        # 默认分析类型
        return "stock_chart"
    
    def _conduct_forum_discussion(self, query_data, analysis_results, user_profile):
        """
        进行多轮论坛讨论
        参数:
            query_data: 查询数据
            analysis_results: 分析结果
            user_profile: 用户画像
        返回:
            论坛讨论结果
        """
        discussions = []
        current_round = 0
        
        # 模拟多轮讨论
        while current_round < self.max_rounds:
            current_round += 1
            print(f"[协调引擎] 论坛讨论第 {current_round} 轮开始...")
            
            # 每轮讨论中，各Agent发表观点
            round_discussion = {
                "round": current_round,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "comments": []
            }
            
            # Query Agent 发表数据见解
            query_comment = self._generate_query_agent_comment(query_data, current_round)
            round_discussion["comments"].append({
                "agent": self.query_agent.name,
                "comment": query_comment,
                "role": self.query_agent.role
            })
            
            # Media Agent 发表分析见解
            media_comment = self._generate_media_agent_comment(analysis_results, current_round)
            round_discussion["comments"].append({
                "agent": self.media_agent.name,
                "comment": media_comment,
                "role": self.media_agent.role
            })
            
            # Insight Agent 发表投资见解
            insight_comment = self._generate_insight_agent_comment(query_data, user_profile, current_round)
            round_discussion["comments"].append({
                "agent": self.insight_agent.name,
                "comment": insight_comment,
                "role": self.insight_agent.role
            })
            
            # 协调引擎总结本轮讨论
            moderator_summary = self._generate_moderator_summary(round_discussion["comments"])
            round_discussion["summary"] = moderator_summary
            
            discussions.append(round_discussion)
            
            # 记录到对话历史
            self._add_to_history("ForumEngine", f"讨论轮次 {current_round}", round_discussion)
        
        # 生成最终论坛结论
        final_conclusion = self._generate_final_conclusion(discussions)
        
        return {
            "rounds": discussions,
            "conclusion": final_conclusion,
            "total_rounds": current_round
        }
    
    def _generate_query_agent_comment(self, query_data, round_num):
        """
        生成Query Agent的评论
        参数:
            query_data: 查询数据
            round_num: 轮次编号
        返回:
            评论内容
        """
        if round_num == 1:
            if "ticker" in query_data:
                return f"基于市场数据，{query_data['ticker']}股票近期表现显示了一定的波动性。我们需要关注其价格趋势、交易量变化以及相关市场新闻，以便更全面地评估其投资价值。"
            elif "market_indexes" in query_data:
                return "根据主要市场指数数据，当前市场整体呈现震荡格局。不同指数表现有所分化，需要进一步分析驱动因素和未来走势。"
            else:
                return "已获取相关市场数据，初步观察显示市场存在结构性机会，但需要更深入的分析来确定具体投资策略。"
        elif round_num == 2:
            return "补充数据显示，除了基本面因素外，市场情绪和资金流向也是影响短期走势的重要因素。建议结合技术面分析来优化入场时机。"
        else:
            return "综合最新数据，我们可以看到某些细分领域出现了明显的投资机会，但同时也需要警惕潜在的风险因素，特别是宏观经济政策变化可能带来的影响。"
    
    def _generate_media_agent_comment(self, analysis_results, round_num):
        """
        生成Media Agent的评论
        参数:
            analysis_results: 分析结果
            round_num: 轮次编号
        返回:
            评论内容
        """
        if round_num == 1:
            if "analysis" in analysis_results:
                analysis = analysis_results["analysis"]
                if "trend" in analysis:
                    return f"从技术分析角度看，当前市场呈现{analysis['trend']}趋势。价格与均线的关系、成交量的变化以及关键技术指标都指向这一判断。"
                else:
                    return "技术分析显示，当前价格走势处于关键位置，需要关注支撑位和阻力位的表现，以及量能配合情况。"
            else:
                return "初步技术分析完成，图表显示存在一定的交易机会，但需要结合其他维度的分析来确认。"
        elif round_num == 2:
            return "进一步的技术指标分析显示，市场可能正在形成新的趋势，特别是某些领先指标已经出现了转向信号。建议密切关注短期价格行为来验证这一判断。"
        else:
            return "综合多种技术分析方法，我们可以更准确地识别潜在的价格目标和风险水平。结合波动率分析，我们可以制定更合理的仓位管理策略。"
    
    def _generate_insight_agent_comment(self, query_data, user_profile, round_num):
        """
        生成Insight Agent的评论
        参数:
            query_data: 查询数据
            user_profile: 用户画像
            round_num: 轮次编号
        返回:
            评论内容
        """
        risk_profile = user_profile.get("risk_profile", "balanced")
        
        if round_num == 1:
            if risk_profile == "conservative":
                return "基于用户的稳健风险偏好，我们建议优先考虑低波动性资产，保持较高比例的固定收益类投资，并严格控制单一标的的风险敞口。"
            elif risk_profile == "balanced":
                return "针对平衡型投资者，我们建议采用核心卫星策略，以稳健资产为核心，辅以适量的成长型资产，并通过分散投资来控制组合风险。"
            else:
                return "对于进取型投资者，可以适当增加权益类资产配置比例，关注高成长性行业和个股，但仍需注意风险控制，避免过度集中投资。"
        elif round_num == 2:
            return "从投资组合构建角度看，我们需要考虑资产相关性、流动性风险以及再平衡策略。建议设置清晰的止损和获利目标，并根据市场变化及时调整策略。"
        else:
            return "综合各方因素，我们认为当前市场环境下，最适合的投资策略是'稳健中寻求进取'，在控制风险的前提下，有选择地参与具有成长性的投资机会。"
    
    def _generate_moderator_summary(self, comments):
        """
        生成协调引擎的总结评论
        参数:
            comments: 本轮讨论的评论列表
        返回:
            总结内容
        """
        summaries = [comment["comment"] for comment in comments]
        
        # 简单的总结逻辑
        summary = "根据各位代理的分析，我们可以得出以下几点共识："
        summary += "\n1. 市场数据显示存在一定的投资机会，但同时也伴随着风险"
        summary += "\n2. 技术分析提供了重要的入场和出场参考"
        summary += "\n3. 投资策略需要根据用户的风险偏好进行个性化定制"
        
        return summary
    
    def _generate_final_conclusion(self, discussions):
        """
        生成论坛讨论的最终结论
        参数:
            discussions: 所有轮次的讨论
        返回:
            最终结论
        """
        conclusion = "通过多轮深入讨论，我们达成以下最终结论：\n"
        
        # 综合各轮讨论的关键点
        conclusion += "\n## 市场判断"
        conclusion += "\n- 当前市场处于复杂多变的环境中，需要综合考虑多种因素"
        conclusion += "\n- 结构性机会与系统性风险并存，需要谨慎选择投资标的"
        conclusion += "\n- 短期波动可能较大，但中长期趋势仍取决于基本面因素"
        
        conclusion += "\n## 投资建议"
        conclusion += "\n- 建议根据个人风险偏好制定差异化的资产配置策略"
        conclusion += "\n- 采用分批建仓和定期再平衡的方式管理投资组合"
        conclusion += "\n- 密切关注市场变化，及时调整投资策略"
        
        conclusion += "\n## 风险提示"
        conclusion += "\n- 市场存在不确定性，投资需谨慎"
        conclusion += "\n- 分散投资是降低风险的有效手段"
        conclusion += "\n- 保持足够的流动性以应对突发情况"
        
        return conclusion
    
    def _add_to_history(self, agent, action, content):
        """
        添加对话历史
        参数:
            agent: 代理名称
            action: 执行的操作
            content: 内容摘要
        """
        history_entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "agent": agent,
            "action": action,
            "content_summary": str(content)[:200] + "..." if len(str(content)) > 200 else str(content)
        }
        self.conversation_history.append(history_entry)
    
    def get_conversation_history(self):
        """
        获取对话历史
        返回:
            对话历史列表
        """
        return self.conversation_history
    
    def reset_history(self):
        """
        重置对话历史
        """
        self.conversation_history = []