import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class AnalysisTools:
    def __init__(self):
        pass
    
    def calculate_returns(self, price_data, period='daily'):
        """
        计算收益率
        参数:
            price_data: 价格数据字典
            period: 收益率类型 ('daily', 'weekly', 'monthly')
        返回:
            收益率数据
        """
        try:
            if isinstance(price_data, dict) and 'Close' in price_data:
                df = pd.DataFrame(price_data)
                if period == 'daily':
                    returns = df['Close'].pct_change().dropna()
                elif period == 'weekly':
                    returns = df['Close'].resample('W').last().pct_change().dropna()
                elif period == 'monthly':
                    returns = df['Close'].resample('M').last().pct_change().dropna()
                return returns.to_dict()
            return {"error": "Invalid price data format"}
        except Exception as e:
            return {"error": str(e)}
    
    def calculate_volatility(self, price_data, window=20):
        """
        计算波动率
        参数:
            price_data: 价格数据字典
            window: 滑动窗口大小
        返回:
            波动率数据
        """
        try:
            if isinstance(price_data, dict) and 'Close' in price_data:
                df = pd.DataFrame(price_data)
                daily_returns = df['Close'].pct_change().dropna()
                volatility = daily_returns.rolling(window=window).std() * np.sqrt(252)  # 年化波动率
                return volatility.to_dict()
            return {"error": "Invalid price data format"}
        except Exception as e:
            return {"error": str(e)}
    
    def calculate_macd(self, price_data, fast_period=12, slow_period=26, signal_period=9):
        """
        计算MACD指标
        参数:
            price_data: 价格数据字典
            fast_period: 快线周期
            slow_period: 慢线周期
            signal_period: 信号线周期
        返回:
            MACD指标数据
        """
        try:
            if isinstance(price_data, dict) and 'Close' in price_data:
                df = pd.DataFrame(price_data)
                exp1 = df['Close'].ewm(span=fast_period, adjust=False).mean()
                exp2 = df['Close'].ewm(span=slow_period, adjust=False).mean()
                macd = exp1 - exp2
                signal = macd.ewm(span=signal_period, adjust=False).mean()
                histogram = macd - signal
                
                return {
                    'macd': macd.to_dict(),
                    'signal': signal.to_dict(),
                    'histogram': histogram.to_dict()
                }
            return {"error": "Invalid price data format"}
        except Exception as e:
            return {"error": str(e)}
    
    def calculate_rsi(self, price_data, period=14):
        """
        计算RSI指标
        参数:
            price_data: 价格数据字典
            period: RSI周期
        返回:
            RSI数据
        """
        try:
            if isinstance(price_data, dict) and 'Close' in price_data:
                df = pd.DataFrame(price_data)
                delta = df['Close'].diff()
                gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
                loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
                rs = gain / loss
                rsi = 100 - (100 / (1 + rs))
                return rsi.to_dict()
            return {"error": "Invalid price data format"}
        except Exception as e:
            return {"error": str(e)}
    
    def analyze_market_trend(self, price_data, period='3mo'):
        """
        分析市场趋势
        参数:
            price_data: 价格数据字典
            period: 分析周期
        返回:
            趋势分析结果
        """
        try:
            if isinstance(price_data, dict) and 'Close' in price_data:
                df = pd.DataFrame(price_data)
                if not df.empty:
                    # 计算简单移动平均线
                    df['SMA50'] = df['Close'].rolling(window=50).mean()
                    df['SMA200'] = df['Close'].rolling(window=200).mean()
                    
                    # 计算趋势强度
                    recent_close = df['Close'].iloc[-1]
                    oldest_close = df['Close'].iloc[0]
                    overall_return = (recent_close - oldest_close) / oldest_close * 100
                    
                    # 确定趋势
                    if df['SMA50'].iloc[-1] > df['SMA200'].iloc[-1] and overall_return > 5:
                        trend = '强劲上涨'
                    elif df['SMA50'].iloc[-1] > df['SMA200'].iloc[-1] and overall_return > 0:
                        trend = '温和上涨'
                    elif df['SMA50'].iloc[-1] < df['SMA200'].iloc[-1] and overall_return < -5:
                        trend = '强劲下跌'
                    elif df['SMA50'].iloc[-1] < df['SMA200'].iloc[-1] and overall_return < 0:
                        trend = '温和下跌'
                    else:
                        trend = '震荡整理'
                    
                    return {
                        "trend": trend,
                        "overall_return_pct": round(overall_return, 2),
                        "sma50": round(df['SMA50'].iloc[-1], 2),
                        "sma200": round(df['SMA200'].iloc[-1], 2),
                        "latest_price": round(recent_close, 2)
                    }
            return {"error": "Invalid price data format"}
        except Exception as e:
            return {"error": str(e)}
    
    def analyze_sector_performance(self, sector_data):
        """
        分析行业板块表现
        参数:
            sector_data: 行业板块数据字典
        返回:
            行业表现分析结果
        """
        try:
            # 模拟行业分析逻辑
            sectors = ['科技', '金融', '医疗', '消费', '能源', '工业', '材料', '公用事业', '电信', '房地产']
            
            # 生成模拟的行业表现数据
            sector_performance = {}
            for sector in sectors:
                if sector in sector_data:
                    perf = sector_data[sector]
                else:
                    # 生成随机表现数据用于演示
                    import random
                    perf = {
                        "return_pct": round(random.uniform(-10, 15), 2),
                        "volatility": round(random.uniform(5, 20), 2),
                        "momentum": round(random.uniform(-1, 1), 2)
                    }
                sector_performance[sector] = perf
            
            # 找出表现最好和最差的行业
            best_sector = max(sector_performance.items(), key=lambda x: x[1]['return_pct'])
            worst_sector = min(sector_performance.items(), key=lambda x: x[1]['return_pct'])
            
            return {
                "sector_performance": sector_performance,
                "best_sector": best_sector[0],
                "best_sector_return": best_sector[1]['return_pct'],
                "worst_sector": worst_sector[0],
                "worst_sector_return": worst_sector[1]['return_pct']
            }
        except Exception as e:
            return {"error": str(e)}
    
    def generate_investment_suggestions(self, market_analysis, risk_profile="balanced"):
        """
        根据市场分析生成投资建议
        参数:
            market_analysis: 市场分析结果
            risk_profile: 风险偏好 ('conservative', 'balanced', 'aggressive')
        返回:
            投资建议
        """
        try:
            suggestions = {
                "asset_allocation": {},
                "sector_rotation": [],
                "risk_management": [],
                "timing": ""
            }
            
            # 根据风险偏好设置资产配置
            if risk_profile == "conservative":
                suggestions["asset_allocation"] = {
                    "stocks": 30,
                    "bonds": 50,
                    "cash": 15,
                    "alternative": 5
                }
                suggestions["risk_management"].append("增加债券配置，降低波动性")
                suggestions["risk_management"].append("保持较高现金储备，应对市场调整")
            elif risk_profile == "balanced":
                suggestions["asset_allocation"] = {
                    "stocks": 50,
                    "bonds": 35,
                    "cash": 10,
                    "alternative": 5
                }
                suggestions["risk_management"].append("定期再平衡投资组合")
                suggestions["risk_management"].append("分散投资于不同行业")
            else:  # aggressive
                suggestions["asset_allocation"] = {
                    "stocks": 70,
                    "bonds": 15,
                    "cash": 5,
                    "alternative": 10
                }
                suggestions["risk_management"].append("设置止损策略")
                suggestions["risk_management"].append("关注市场估值水平")
            
            # 根据市场趋势调整建议
            if "trend" in market_analysis:
                if market_analysis["trend"] in ["强劲上涨", "温和上涨"]:
                    suggestions["timing"] = "市场处于上升趋势，可以考虑逐步建仓"
                    suggestions["sector_rotation"].append("关注表现强势的行业")
                elif market_analysis["trend"] in ["强劲下跌", "温和下跌"]:
                    suggestions["timing"] = "市场处于下跌趋势，建议观望为主"
                    suggestions["sector_rotation"].append("考虑防御性行业配置")
                else:
                    suggestions["timing"] = "市场处于震荡整理，可以考虑高抛低吸策略"
                    suggestions["sector_rotation"].append("关注估值合理的优质企业")
            
            return suggestions
        except Exception as e:
            return {"error": str(e)}