import requests
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class FinancialDataTools:
    def __init__(self):
        self.alpha_vantage_api_key = os.getenv('ALPHA_VANTAGE_API_KEY', 'demo')
        self.iex_cloud_api_key = os.getenv('IEX_CLOUD_API_KEY', 'demo')
    
    def get_stock_price(self, ticker, period='1mo'):
        """
        获取股票价格数据
        参数:
            ticker: 股票代码
            period: 时间周期 (1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
        返回:
            pandas DataFrame 包含价格数据
        """
        try:
            stock = yf.Ticker(ticker)
            data = stock.history(period=period)
            return data.to_dict()
        except Exception as e:
            return {"error": str(e)}
    
    def get_market_news(self, query, count=10):
        """
        获取金融市场新闻
        参数:
            query: 搜索关键词
            count: 返回数量
        返回:
            新闻列表
        """
        try:
            # 使用Alpha Vantage获取新闻（示例）
            url = f"https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers={query}&apikey={self.alpha_vantage_api_key}"
            response = requests.get(url)
            if response.status_code == 200:
                return response.json()
            # 模拟返回新闻数据
            return {
                "feed": [
                    {"title": f"{query}相关新闻{i}", "url": f"https://example.com/news/{i}", "time_published": str(datetime.now()), "summary": f"这是关于{query}的新闻摘要{i}"}
                    for i in range(count)
                ]
            }
        except Exception as e:
            return {"error": str(e)}
    
    def get_company_financials(self, ticker):
        """
        获取公司财务数据
        参数:
            ticker: 股票代码
        返回:
            财务数据字典
        """
        try:
            stock = yf.Ticker(ticker)
            financials = {
                "income_statement": stock.financials.to_dict(),
                "balance_sheet": stock.balance_sheet.to_dict(),
                "cash_flow": stock.cashflow.to_dict()
            }
            return financials
        except Exception as e:
            return {"error": str(e)}
    
    def get_market_indexes(self, indexes=None):
        """
        获取主要市场指数
        参数:
            indexes: 指数列表，默认获取常见指数
        返回:
            指数数据字典
        """
        if indexes is None:
            indexes = ['^GSPC', '^DJI', '^IXIC', '^HSI', '^N225', '^FTSE']
        
        results = {}
        for index in indexes:
            try:
                ticker = yf.Ticker(index)
                data = ticker.history(period='1d')
                if not data.empty:
                    results[index] = {
                        "current": data['Close'].iloc[-1],
                        "open": data['Open'].iloc[-1],
                        "high": data['High'].iloc[-1],
                        "low": data['Low'].iloc[-1],
                        "volume": data['Volume'].iloc[-1]
                    }
            except Exception as e:
                results[index] = {"error": str(e)}
        
        return results
    
    def get_crypto_data(self, symbol='BTC-USD', period='1mo'):
        """
        获取加密货币数据
        参数:
            symbol: 加密货币符号
            period: 时间周期
        返回:
            价格数据
        """
        try:
            crypto = yf.Ticker(symbol)
            data = crypto.history(period=period)
            return data.to_dict()
        except Exception as e:
            return {"error": str(e)}
    
    def get_forex_rates(self, from_currency='USD', to_currencies=None):
        """
        获取外汇汇率
        参数:
            from_currency: 基础货币
            to_currencies: 目标货币列表
        返回:
            汇率数据
        """
        if to_currencies is None:
            to_currencies = ['CNY', 'EUR', 'JPY', 'GBP', 'AUD']
        
        results = {}
        for currency in to_currencies:
            try:
                pair = f'{from_currency}{currency}=X'
                ticker = yf.Ticker(pair)
                data = ticker.history(period='1d')
                if not data.empty:
                    results[currency] = data['Close'].iloc[-1]
            except Exception as e:
                results[currency] = {"error": str(e)}
        
        return results