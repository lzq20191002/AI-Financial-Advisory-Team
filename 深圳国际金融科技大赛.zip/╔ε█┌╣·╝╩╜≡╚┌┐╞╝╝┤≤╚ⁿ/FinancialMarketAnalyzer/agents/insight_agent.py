import os
import json
from datetime import datetime
from tools.analysis_tools import AnalysisTools
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class InsightAgent:
    def __init__(self, analysis_tools=None):
        self.analysis_tools = analysis_tools if analysis_tools else AnalysisTools()
        self.name = "金融洞察代理"
        self.role = "负责深度金融分析、投资组合优化和个性化投资建议生成"
    
    def generate_insights(self, data, user_profile=None):
        """
        生成金融洞察和投资建议
        参数:
            data: 分析所需的数据
            user_profile: 用户画像（风险偏好、投资目标等）
        返回:
            洞察和建议
        """
        if user_profile is None:
            user_profile = {
                "risk_profile": "balanced",  # conservative, balanced, aggressive
                "investment_horizon": "medium",  # short, medium, long
                "investment_goal": "wealth_growth",  # capital_preservation, income, wealth_growth
                "age": 35,
                "investment_experience": "intermediate"  # beginner, intermediate, advanced
            }
        
        insights = {
            "market_insights": {},
            "investment_suggestions": {},
            "risk_assessment": {},
            "portfolio_recommendations": {},
            "timestamp": self._get_timestamp()
        }
        
        # 生成市场洞察
        insights["market_insights"] = self._generate_market_insights(data)
        
        # 生成投资建议
        insights["investment_suggestions"] = self._generate_investment_suggestions(
            data, user_profile["risk_profile"]
        )
        
        # 风险评估
        insights["risk_assessment"] = self._assess_risk(data, user_profile)
        
        # 投资组合建议
        insights["portfolio_recommendations"] = self._recommend_portfolio(user_profile)
        
        return insights
    
    def _generate_market_insights(self, data):
        """
        生成市场洞察
        参数:
            data: 市场数据
        返回:
            市场洞察
        """
        market_insights = {
            "market_outlook": "",
            "sector_trends": [],
            "key_metrics": {},
            "risk_factors": []
        }
        
        # 分析市场趋势
        if isinstance(data, dict):
            # 检查是否有股票价格数据
            if "price_data" in data and data["price_data"]:
                trend_analysis = self.analysis_tools.analyze_market_trend(data["price_data"])
                if "trend" in trend_analysis:
                    market_insights["market_outlook"] = self._interpret_trend(trend_analysis)
            
            # 检查是否有行业数据
            if "sector_performance" in data:
                sector_analysis = self.analysis_tools.analyze_sector_performance(data["sector_performance"])
                if "sector_performance" in sector_analysis:
                    market_insights["sector_trends"] = self._extract_sector_trends(sector_analysis)
        
        # 如果没有足够的数据，提供一般性洞察
        if not market_insights["market_outlook"]:
            market_insights["market_outlook"] = "当前市场处于动态变化中，建议关注宏观经济指标和政策变化对市场的潜在影响。"
        
        # 添加关键指标
        market_insights["key_metrics"] = {
            "inflation_concern": "中等",
            "interest_rate_outlook": "稳中有升",
            "market_valuation": "中性偏高",
            "geopolitical_risk": "中等"
        }
        
        # 添加风险因素
        market_insights["risk_factors"] = [
            "全球经济增长放缓可能影响企业盈利",
            "通胀压力可能导致货币政策收紧",
            "地缘政治紧张局势可能引发市场波动",
            "行业监管变化可能影响特定板块"
        ]
        
        return market_insights
    
    def _interpret_trend(self, trend_analysis):
        """
        解释市场趋势
        参数:
            trend_analysis: 趋势分析结果
        返回:
            趋势解释文本
        """
        if trend_analysis["trend"] == "强劲上涨":
            return f"市场显示强劲上涨趋势，近三个月涨幅达{trend_analysis['overall_return_pct']}%。技术面指标良好，50日均线位于200日均线上方，表明中期上升趋势确立。"
        elif trend_analysis["trend"] == "温和上涨":
            return f"市场呈现温和上涨态势，涨幅为{trend_analysis['overall_return_pct']}%。短期动能较强，但需关注上方阻力位。"
        elif trend_analysis["trend"] == "强劲下跌":
            return f"市场处于明显下跌趋势，跌幅达{abs(trend_analysis['overall_return_pct'])}%。技术面走弱，建议保持谨慎，控制仓位。"
        elif trend_analysis["trend"] == "温和下跌":
            return f"市场出现温和调整，跌幅为{abs(trend_analysis['overall_return_pct'])}%。可能是短期回调，建议关注支撑位表现。"
        else:  # 震荡整理
            return f"市场处于震荡整理阶段，整体波动不大。建议选择业绩稳定、估值合理的优质个股，并关注市场突破方向。"
    
    def _extract_sector_trends(self, sector_analysis):
        """
        提取行业趋势
        参数:
            sector_analysis: 行业分析结果
        返回:
            行业趋势列表
        """
        trends = []
        if "sector_performance" in sector_analysis:
            sectors = sector_analysis["sector_performance"]
            # 找出表现最好和最差的前三个行业
            sorted_sectors = sorted(sectors.items(), key=lambda x: x[1].get("return_pct", 0), reverse=True)
            
            # 分析强势行业
            for i, (sector, data) in enumerate(sorted_sectors[:3]):
                if "return_pct" in data:
                    trend_text = f"{sector}行业表现突出，涨幅达{data['return_pct']}%，"
                    # 根据不同行业添加解释
                    if sector == "科技":
                        trend_text += "受益于人工智能和数字化转型加速。"
                    elif sector == "医疗":
                        trend_text += "受到人口老龄化和创新药物研发推动。"
                    elif sector == "消费":
                        trend_text += "随着消费信心恢复和内需扩大而增长。"
                    else:
                        trend_text += "显示出良好的成长性和盈利能力。"
                    trends.append(trend_text)
            
            # 分析弱势行业
            for i, (sector, data) in enumerate(sorted_sectors[-2:]):
                if "return_pct" in data and data["return_pct"] < 0:
                    trend_text = f"{sector}行业表现不佳，跌幅为{abs(data['return_pct'])}%，"
                    # 根据不同行业添加解释
                    if sector == "能源":
                        trend_text += "可能受到大宗商品价格波动影响。"
                    elif sector == "金融":
                        trend_text += "面临利率环境变化和监管压力。"
                    else:
                        trend_text += "需要关注基本面改善情况。"
                    trends.append(trend_text)
        
        # 如果没有足够的行业数据，提供一般性趋势
        if not trends:
            trends = [
                "科技行业继续引领市场创新，但估值已处高位",
                "医疗健康行业受益于需求增长和政策支持",
                "消费升级趋势明显，高端消费品表现强劲"
            ]
        
        return trends
    
    def _generate_investment_suggestions(self, data, risk_profile):
        """
        生成投资建议
        参数:
            data: 市场数据
            risk_profile: 风险偏好
        返回:
            投资建议
        """
        # 获取市场趋势分析
        market_analysis = {}
        if isinstance(data, dict) and "price_data" in data:
            market_analysis = self.analysis_tools.analyze_market_trend(data["price_data"])
        
        # 生成投资建议
        suggestions = self.analysis_tools.generate_investment_suggestions(market_analysis, risk_profile)
        
        # 根据风险偏好添加个性化建议
        personalized_suggestions = {
            "general_advice": "",
            "asset_allocation": suggestions.get("asset_allocation", {}),
            "sector_rotation": suggestions.get("sector_rotation", []),
            "entry_exit_strategy": "",
            "timing": suggestions.get("timing", ""),
            "risk_management": suggestions.get("risk_management", [])
        }
        
        # 根据风险偏好设置一般性建议
        if risk_profile == "conservative":
            personalized_suggestions["general_advice"] = "建议以保本为主，配置较高比例的债券和现金类资产，少量参与优质蓝筹股投资。"
            personalized_suggestions["entry_exit_strategy"] = "分批建仓，设置严格止损，避免追高。"
        elif risk_profile == "balanced":
            personalized_suggestions["general_advice"] = "采用股债平衡策略，选择成长性和价值型股票均衡配置，定期再平衡投资组合。"
            personalized_suggestions["entry_exit_strategy"] = "逢低吸纳，波段操作，关注市场估值水平。"
        else:  # aggressive
            personalized_suggestions["general_advice"] = "可以适当提高权益类资产配置，关注高成长性行业和个股，但需注意风险控制。"
            personalized_suggestions["entry_exit_strategy"] = "把握市场热点轮动机会，灵活调整仓位，设置止盈止损。"
        
        return personalized_suggestions
    
    def _assess_risk(self, data, user_profile):
        """
        进行风险评估
        参数:
            data: 市场数据
            user_profile: 用户画像
        返回:
            风险评估结果
        """
        risk_assessment = {
            "market_risk_level": "中等",
            "recommended_position_size": "",
            "risk_factors": [],
            "mitigation_strategies": []
        }
        
        # 根据用户风险偏好设置建议仓位
        if user_profile["risk_profile"] == "conservative":
            risk_assessment["recommended_position_size"] = "单个标的不超过总资产的3%"
            risk_assessment["risk_factors"].append("市场大幅波动风险")
            risk_assessment["mitigation_strategies"].append("分散投资于不同资产类别")
        elif user_profile["risk_profile"] == "balanced":
            risk_assessment["recommended_position_size"] = "单个标的不超过总资产的5%"
            risk_assessment["risk_factors"].append("行业集中风险")
            risk_assessment["mitigation_strategies"].append("跨行业配置，定期再平衡")
        else:
            risk_assessment["recommended_position_size"] = "单个标的不超过总资产的10%"
            risk_assessment["risk_factors"].append("个股波动风险")
            risk_assessment["mitigation_strategies"].append("设置严格止损，关注流动性")
        
        # 根据投资期限调整风险评估
        if user_profile["investment_horizon"] == "short":
            risk_assessment["market_risk_level"] = "较高"
            risk_assessment["risk_factors"].append("短期市场波动风险")
            risk_assessment["mitigation_strategies"].append("降低权益类资产配置比例")
        elif user_profile["investment_horizon"] == "long":
            risk_assessment["market_risk_level"] = "较低"
            risk_assessment["mitigation_strategies"].append("坚持长期投资，忽略短期波动")
        
        return risk_assessment
    
    def _recommend_portfolio(self, user_profile):
        """
        推荐投资组合
        参数:
            user_profile: 用户画像
        返回:
            投资组合建议
        """
        # 基础资产配置
        base_allocation = {
            "conservative": {
                "股票": 30,
                "债券": 50,
                "现金及等价物": 15,
                "另类资产": 5
            },
            "balanced": {
                "股票": 50,
                "债券": 35,
                "现金及等价物": 10,
                "另类资产": 5
            },
            "aggressive": {
                "股票": 70,
                "债券": 15,
                "现金及等价物": 5,
                "另类资产": 10
            }
        }
        
        # 股票内部行业配置
        sector_allocation = {
            "conservative": {
                "大金融": 25,
                "消费蓝筹": 25,
                "公用事业": 20,
                "医药健康": 15,
                "科技龙头": 15
            },
            "balanced": {
                "科技成长": 25,
                "医药健康": 20,
                "消费升级": 20,
                "先进制造": 15,
                "金融地产": 10,
                "新能源": 10
            },
            "aggressive": {
                "科技创新": 30,
                "新能源": 20,
                "高端制造": 15,
                "医药创新": 15,
                "消费电子": 10,
                "其他成长": 10
            }
        }
        
        # 根据用户风险偏好获取配置
        risk_profile = user_profile["risk_profile"]
        allocation = base_allocation.get(risk_profile, base_allocation["balanced"])
        sectors = sector_allocation.get(risk_profile, sector_allocation["balanced"])
        
        # 投资组合建议
        portfolio = {
            "asset_allocation": allocation,
            "sector_allocation": sectors,
            "investment_vehicles": [],
            "rebalancing_strategy": ""
        }
        
        # 推荐投资工具
        if risk_profile == "conservative":
            portfolio["investment_vehicles"] = [
                "宽基指数ETF",
                "高评级公司债",
                "货币基金",
                "红利型股票"
            ]
        elif risk_profile == "balanced":
            portfolio["investment_vehicles"] = [
                "行业ETF组合",
                "优质成长股",
                "中短期债券基金",
                "部分REITs产品"
            ]
        else:
            portfolio["investment_vehicles"] = [
                "主题ETF",
                "成长型股票",
                "科技类基金",
                "少量优质数字资产"
            ]
        
        # 设置再平衡策略
        portfolio["rebalancing_strategy"] = "建议每季度评估一次投资组合表现，当各类资产配置偏离目标比例超过5%时进行再平衡。"
        
        return portfolio
    
    def _get_timestamp(self):
        """
        获取当前时间戳
        返回:
            时间戳字符串
        """
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")