import os
import json
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from datetime import datetime
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class MediaAgent:
    def __init__(self, analysis_tools=None):
        self.analysis_tools = analysis_tools
        self.name = "金融分析代理"
        self.role = "负责处理金融数据可视化、图表分析和市场趋势识别"
        self.output_dir = os.path.join(os.path.dirname(__file__), "..", "static", "charts")
        os.makedirs(self.output_dir, exist_ok=True)
    
    def analyze_data(self, data, analysis_type):
        """
        分析金融数据
        参数:
            data: 要分析的数据
            analysis_type: 分析类型
        返回:
            分析结果和图表路径
        """
        if analysis_type == "stock_chart":
            return self._create_stock_chart(data)
        elif analysis_type == "market_trend":
            return self._analyze_market_trend(data)
        elif analysis_type == "sector_comparison":
            return self._compare_sectors(data)
        elif analysis_type == "portfolio_allocation":
            return self._create_portfolio_chart(data)
        elif analysis_type == "volatility_analysis":
            return self._analyze_volatility(data)
        else:
            return {"error": "未知的分析类型"}
    
    def _create_stock_chart(self, stock_data):
        """
        创建股票价格图表
        参数:
            stock_data: 股票数据
        返回:
            图表路径和分析结果
        """
        try:
            if isinstance(stock_data, dict) and "ticker" in stock_data and "price_data" in stock_data:
                ticker = stock_data["ticker"]
                price_data = stock_data["price_data"]
                
                if "Close" in price_data:
                    # 转换为DataFrame
                    df = pd.DataFrame(price_data)
                    
                    # 创建图表
                    plt.figure(figsize=(12, 6))
                    plt.plot(df.index, df['Close'], label=ticker)
                    
                    # 添加移动平均线
                    if len(df) > 50:
                        df['SMA50'] = df['Close'].rolling(window=50).mean()
                        plt.plot(df.index, df['SMA50'], label='50日均线', linestyle='--')
                    if len(df) > 200:
                        df['SMA200'] = df['Close'].rolling(window=200).mean()
                        plt.plot(df.index, df['SMA200'], label='200日均线', linestyle='-.')
                    
                    plt.title(f'{ticker} 价格走势图')
                    plt.xlabel('日期')
                    plt.ylabel('价格')
                    plt.legend()
                    plt.grid(True)
                    
                    # 保存图表
                    chart_path = os.path.join(self.output_dir, f'{ticker}_price_chart.png')
                    plt.savefig(chart_path)
                    plt.close()
                    
                    # 计算基本统计数据
                    latest_price = df['Close'].iloc[-1]
                    start_price = df['Close'].iloc[0]
                    price_change = latest_price - start_price
                    percent_change = (price_change / start_price) * 100
                    
                    return {
                        "chart_path": chart_path,
                        "analysis": {
                            "ticker": ticker,
                            "latest_price": round(latest_price, 2),
                            "price_change": round(price_change, 2),
                            "percent_change": round(percent_change, 2),
                            "period_start": str(df.index[0].date()),
                            "period_end": str(df.index[-1].date())
                        }
                    }
            return {"error": "无效的股票数据格式"}
        except Exception as e:
            return {"error": str(e)}
    
    def _analyze_market_trend(self, market_data):
        """
        分析市场趋势
        参数:
            market_data: 市场数据
        返回:
            趋势分析结果和图表路径
        """
        try:
            if isinstance(market_data, dict) and "market_indexes" in market_data:
                indexes = market_data["market_indexes"]
                
                # 准备数据用于可视化
                index_names = []
                current_values = []
                changes = []
                
                for index, data in indexes.items():
                    if isinstance(data, dict) and "current" in data and "open" in data:
                        index_names.append(index)
                        current_values.append(data["current"])
                        change = ((data["current"] - data["open"]) / data["open"]) * 100
                        changes.append(change)
                
                # 创建市场指数对比图表
                plt.figure(figsize=(12, 6))
                
                # 使用不同颜色表示涨跌
                colors = ['green' if x > 0 else 'red' for x in changes]
                
                bars = plt.bar(index_names, changes, color=colors)
                plt.title('主要市场指数当日涨跌幅(%)')
                plt.xlabel('指数')
                plt.ylabel('涨跌幅(%)')
                plt.grid(True, axis='y')
                
                # 在柱状图上添加数值标签
                for bar in bars:
                    height = bar.get_height()
                    plt.text(bar.get_x() + bar.get_width()/2., height,
                            f'{height:.2f}%', ha='center', va='bottom' if height > 0 else 'top')
                
                # 保存图表
                chart_path = os.path.join(self.output_dir, 'market_trends.png')
                plt.savefig(chart_path)
                plt.close()
                
                # 分析市场整体趋势
                avg_change = sum(changes) / len(changes) if changes else 0
                if avg_change > 1:
                    overall_trend = "强劲上涨"
                elif avg_change > 0:
                    overall_trend = "温和上涨"
                elif avg_change < -1:
                    overall_trend = "强劲下跌"
                elif avg_change < 0:
                    overall_trend = "温和下跌"
                else:
                    overall_trend = "横盘震荡"
                
                return {
                    "chart_path": chart_path,
                    "analysis": {
                        "overall_trend": overall_trend,
                        "average_change": round(avg_change, 2),
                        "index_performances": {}
                    }
                }
            return {"error": "无效的市场数据格式"}
        except Exception as e:
            return {"error": str(e)}
    
    def _compare_sectors(self, sector_data):
        """
        比较不同行业板块的表现
        参数:
            sector_data: 行业数据
        返回:
            比较结果和图表路径
        """
        try:
            if isinstance(sector_data, dict) and "sector_performance" in sector_data:
                sectors = sector_data["sector_performance"]
                
                sector_names = []
                returns = []
                
                for sector, data in sectors.items():
                    if isinstance(data, dict) and "return_pct" in data:
                        sector_names.append(sector)
                        returns.append(data["return_pct"])
                
                # 创建行业表现对比图表
                plt.figure(figsize=(14, 8))
                
                # 按收益率排序
                sorted_indices = sorted(range(len(returns)), key=lambda i: returns[i], reverse=True)
                sorted_sectors = [sector_names[i] for i in sorted_indices]
                sorted_returns = [returns[i] for i in sorted_indices]
                
                # 使用渐变色
                colors = plt.cm.RdYlGn_r(np.linspace(0, 1, len(sorted_returns)))
                
                bars = plt.barh(sorted_sectors, sorted_returns, color=colors)
                plt.title('各行业板块收益率对比(%)')
                plt.xlabel('收益率(%)')
                plt.grid(True, axis='x')
                
                # 添加数值标签
                for bar in bars:
                    width = bar.get_width()
                    plt.text(width + 0.1, bar.get_y() + bar.get_height()/2.,
                            f'{width:.2f}%', va='center')
                
                # 保存图表
                chart_path = os.path.join(self.output_dir, 'sector_comparison.png')
                plt.savefig(chart_path)
                plt.close()
                
                return {
                    "chart_path": chart_path,
                    "analysis": {
                        "best_performing_sector": sorted_sectors[0],
                        "best_return": round(sorted_returns[0], 2),
                        "worst_performing_sector": sorted_sectors[-1],
                        "worst_return": round(sorted_returns[-1], 2),
                        "sector_count": len(sorted_sectors)
                    }
                }
            return {"error": "无效的行业数据格式"}
        except Exception as e:
            return {"error": str(e)}
    
    def _create_portfolio_chart(self, allocation_data):
        """
        创建投资组合配置饼图
        参数:
            allocation_data: 资产配置数据
        返回:
            图表路径和分析结果
        """
        try:
            if isinstance(allocation_data, dict) and "asset_allocation" in allocation_data:
                allocation = allocation_data["asset_allocation"]
                
                # 创建饼图
                plt.figure(figsize=(10, 8))
                
                # 设置颜色
                colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#c2c2f0', '#ffb3e6']
                
                # 创建饼图
                wedges, texts, autotexts = plt.pie(
                    allocation.values(), 
                    labels=allocation.keys(),
                    autopct='%1.1f%%',
                    startangle=90,
                    colors=colors
                )
                
                # 设置文本样式
                for autotext in autotexts:
                    autotext.set_color('white')
                    autotext.set_weight('bold')
                
                plt.axis('equal')  # 确保饼图是圆的
                plt.title('投资组合资产配置')
                
                # 添加图例
                plt.legend(wedges, [f'{k}: {v}%' for k, v in allocation.items()],
                          title="资产类别", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
                
                # 保存图表
                chart_path = os.path.join(self.output_dir, 'portfolio_allocation.png')
                plt.savefig(chart_path, bbox_inches='tight')
                plt.close()
                
                return {
                    "chart_path": chart_path,
                    "analysis": {
                        "allocation": allocation,
                        "total_percentage": sum(allocation.values()),
                        "dominant_asset": max(allocation.items(), key=lambda x: x[1])[0]
                    }
                }
            return {"error": "无效的资产配置数据格式"}
        except Exception as e:
            return {"error": str(e)}
    
    def _analyze_volatility(self, volatility_data):
        """
        分析波动率数据
        参数:
            volatility_data: 波动率数据
        返回:
            分析结果和图表路径
        """
        try:
            if isinstance(volatility_data, dict):
                # 模拟波动率分析（实际应用中应根据传入的具体数据格式进行处理）
                plt.figure(figsize=(12, 6))
                
                # 生成模拟的波动率数据
                dates = pd.date_range(end=datetime.now(), periods=60)
                volatility = np.random.normal(0.15, 0.05, size=60)
                volatility = np.maximum(volatility, 0.01)  # 确保波动率为正
                
                plt.plot(dates, volatility * 100, label='年化波动率(%)')
                plt.axhline(y=15, color='r', linestyle='--', label='15% 基准线')
                plt.title('市场波动率趋势')
                plt.xlabel('日期')
                plt.ylabel('波动率(%)')
                plt.legend()
                plt.grid(True)
                
                # 保存图表
                chart_path = os.path.join(self.output_dir, 'volatility_analysis.png')
                plt.savefig(chart_path)
                plt.close()
                
                # 分析波动率趋势
                avg_volatility = np.mean(volatility) * 100
                if avg_volatility > 20:
                    volatility_level = "高"
                elif avg_volatility > 10:
                    volatility_level = "中"
                else:
                    volatility_level = "低"
                
                return {
                    "chart_path": chart_path,
                    "analysis": {
                        "average_volatility": round(avg_volatility, 2),
                        "volatility_level": volatility_level,
                        "latest_volatility": round(volatility[-1] * 100, 2)
                    }
                }
            return {"error": "无效的波动率数据格式"}
        except Exception as e:
            return {"error": str(e)}