import os
import requests
from tools.financial_data_tools import FinancialDataTools
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class QueryAgent:
    def __init__(self, financial_tools=None):
        self.financial_tools = financial_tools if financial_tools else FinancialDataTools()
        self.name = "金融查询代理"
        self.role = "负责搜索和获取金融市场数据、股票信息、市场新闻和宏观经济指标"
    
    def process_request(self, query):
        """
        处理用户查询请求
        参数:
            query: 查询内容
        返回:
            查询结果
        """
        # 解析查询意图
        intent = self._parse_intent(query)
        
        # 根据意图调用相应的工具
        if intent["type"] == "stock_price":
            return self._get_stock_info(intent["ticker"])
        elif intent["type"] == "market_news":
            return self._get_market_news(intent["keywords"])
        elif intent["type"] == "market_indexes":
            return self._get_market_overview()
        elif intent["type"] == "crypto":
            return self._get_crypto_data(intent["symbol"])
        elif intent["type"] == "forex":
            return self._get_forex_data(intent["currency"])
        elif intent["type"] == "company_financials":
            return self._get_company_financials(intent["ticker"])
        else:
            return {"error": "无法理解您的查询意图，请尝试更具体的问题"}
    
    def _parse_intent(self, query):
        """
        解析查询意图
        参数:
            query: 查询文本
        返回:
            意图字典
        """
        query_lower = query.lower()
        
        # 股票价格查询
        if any(keyword in query_lower for keyword in ["股价", "股票价格", "股票走势", "股票分析"]):
            # 简单提取股票代码（实际应用中可以使用更复杂的NLP）
            ticker = self._extract_ticker(query)
            return {"type": "stock_price", "ticker": ticker if ticker else "AAPL"}  # 默认AAPL
        
        # 市场新闻查询
        elif any(keyword in query_lower for keyword in ["新闻", "市场动态", "财经新闻"]):
            keywords = query_lower.replace("新闻", "").replace("市场动态", "").replace("财经新闻", "").strip()
            return {"type": "market_news", "keywords": keywords if keywords else "股市"}
        
        # 市场指数查询
        elif any(keyword in query_lower for keyword in ["大盘", "指数", "市场概况", "市场指数"]):
            return {"type": "market_indexes"}
        
        # 加密货币查询
        elif any(keyword in query_lower for keyword in ["比特币", "加密货币", "数字货币", "虚拟货币"]):
            if "比特币" in query_lower or "BTC" in query.upper():
                symbol = "BTC-USD"
            elif "以太坊" in query_lower or "ETH" in query.upper():
                symbol = "ETH-USD"
            else:
                symbol = "BTC-USD"  # 默认比特币
            return {"type": "crypto", "symbol": symbol}
        
        # 外汇查询
        elif any(keyword in query_lower for keyword in ["汇率", "外汇", "货币兑换"]):
            if "美元" in query_lower or "USD" in query.upper():
                currency = "USD"
            elif "欧元" in query_lower or "EUR" in query.upper():
                currency = "EUR"
            else:
                currency = "USD"  # 默认美元
            return {"type": "forex", "currency": currency}
        
        # 公司财务查询
        elif any(keyword in query_lower for keyword in ["财务", "财报", "财务分析", "业绩"]):
            ticker = self._extract_ticker(query)
            return {"type": "company_financials", "ticker": ticker if ticker else "AAPL"}  # 默认AAPL
        
        else:
            return {"type": "unknown"}
    
    def _extract_ticker(self, query):
        """
        从查询中提取股票代码
        参数:
            query: 查询文本
        返回:
            股票代码
        """
        # 这里使用简单的关键词匹配，实际应用中可以使用更复杂的NLP
        common_tickers = {
            "苹果": "AAPL", "微软": "MSFT", "谷歌": "GOOGL", "亚马逊": "AMZN", "特斯拉": "TSLA",
            "脸书": "META", "英伟达": "NVDA", "阿里巴巴": "BABA", "腾讯": "0700.HK", "京东": "JD",
            "贵州茅台": "600519.SS", "工商银行": "601398.SS", "中国平安": "601318.SS", "招商银行": "600036.SS"
        }
        
        # 检查是否包含已知股票代码
        for keyword, ticker in common_tickers.items():
            if keyword in query:
                return ticker
        
        # 检查是否直接包含股票代码格式的内容（简单判断）
        words = query.split()
        for word in words:
            # 简单判断是否为可能的股票代码
            if (len(word) >= 3 and len(word) <= 8 and word.isupper() and word.isalnum()) or \
               (word.endswith(".SS") or word.endswith(".SZ") or word.endswith(".HK")):
                return word
        
        return None
    
    def _get_stock_info(self, ticker):
        """
        获取股票详细信息
        参数:
            ticker: 股票代码
        返回:
            股票信息
        """
        price_data = self.financial_tools.get_stock_price(ticker, period="3mo")
        news = self.financial_tools.get_market_news(ticker, count=5)
        
        return {
            "ticker": ticker,
            "price_data": price_data,
            "recent_news": news,
            "timestamp": self._get_timestamp()
        }
    
    def _get_market_news(self, keywords):
        """
        获取市场新闻
        参数:
            keywords: 关键词
        返回:
            新闻列表
        """
        news = self.financial_tools.get_market_news(keywords, count=10)
        return {
            "keywords": keywords,
            "news": news,
            "timestamp": self._get_timestamp()
        }
    
    def _get_market_overview(self):
        """
        获取市场概览
        返回:
            主要市场指数数据
        """
        indexes = self.financial_tools.get_market_indexes()
        return {
            "market_indexes": indexes,
            "timestamp": self._get_timestamp()
        }
    
    def _get_crypto_data(self, symbol):
        """
        获取加密货币数据
        参数:
            symbol: 加密货币符号
        返回:
            加密货币数据
        """
        crypto_data = self.financial_tools.get_crypto_data(symbol, period="1mo")
        return {
            "symbol": symbol,
            "data": crypto_data,
            "timestamp": self._get_timestamp()
        }
    
    def _get_forex_data(self, currency):
        """
        获取外汇数据
        参数:
            currency: 货币代码
        返回:
            外汇汇率数据
        """
        rates = self.financial_tools.get_forex_rates(currency)
        return {
            "base_currency": currency,
            "exchange_rates": rates,
            "timestamp": self._get_timestamp()
        }
    
    def _get_company_financials(self, ticker):
        """
        获取公司财务数据
        参数:
            ticker: 股票代码
        返回:
            财务数据
        """
        financials = self.financial_tools.get_company_financials(ticker)
        price_data = self.financial_tools.get_stock_price(ticker, period="1mo")
        
        return {
            "ticker": ticker,
            "financials": financials,
            "recent_prices": price_data,
            "timestamp": self._get_timestamp()
        }
    
    def _get_timestamp(self):
        """
        获取当前时间戳
        返回:
            时间戳字符串
        """
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")