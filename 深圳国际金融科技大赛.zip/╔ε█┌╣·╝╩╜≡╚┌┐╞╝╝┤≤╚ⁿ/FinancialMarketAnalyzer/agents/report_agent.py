import os
import json
from datetime import datetime
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class ReportAgent:
    def __init__(self):
        self.name = "报告生成代理"
        self.role = "负责整合分析结果，生成结构化的金融市场分析报告"
        self.report_dir = os.path.join(os.path.dirname(__file__), "..", "reports")
        os.makedirs(self.report_dir, exist_ok=True)
    
    def generate_report(self, query_data, analysis_results, insights, user_profile=None):
        """
        生成综合分析报告
        参数:
            query_data: 查询数据
            analysis_results: 分析结果
            insights: 深度洞察
            user_profile: 用户画像
        返回:
            报告内容和报告路径
        """
        if user_profile is None:
            user_profile = {
                "risk_profile": "balanced",
                "name": "用户"
            }
        
        # 生成报告内容
        report_content = {
            "report_id": self._generate_report_id(),
            "title": self._generate_report_title(query_data),
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "user_profile": user_profile,
            "executive_summary": "",
            "market_analysis": {},
            "investment_recommendations": {},
            "risk_assessment": {},
            "conclusion": ""
        }
        
        # 生成摘要
        report_content["executive_summary"] = self._generate_summary(query_data, insights)
        
        # 添加市场分析
        report_content["market_analysis"] = self._compile_market_analysis(query_data, analysis_results, insights)
        
        # 添加投资建议
        report_content["investment_recommendations"] = self._compile_recommendations(insights, user_profile)
        
        # 添加风险评估
        report_content["risk_assessment"] = insights.get("risk_assessment", {})
        
        # 添加结论
        report_content["conclusion"] = self._generate_conclusion(insights, user_profile)
        
        # 保存报告
        report_path = self._save_report(report_content)
        
        # 生成HTML格式报告
        html_report = self._generate_html_report(report_content)
        html_report_path = self._save_html_report(html_report, report_content["report_id"])
        
        return {
            "report": report_content,
            "report_path": report_path,
            "html_report_path": html_report_path,
            "formatted_report": self._format_report_for_display(report_content)
        }
    
    def _generate_report_id(self):
        """
        生成报告ID
        返回:
            唯一的报告ID
        """
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        return f"REPORT_{timestamp}"
    
    def _generate_report_title(self, query_data):
        """
        生成报告标题
        参数:
            query_data: 查询数据
        返回:
            报告标题
        """
        # 解析查询数据，生成合适的标题
        if isinstance(query_data, dict):
            if "ticker" in query_data:
                return f"{query_data['ticker']} 股票分析与投资建议报告"
            elif "keywords" in query_data:
                return f"{query_data['keywords']} 相关市场分析报告"
            elif "type" in query_data and query_data["type"] == "market_indexes":
                return "全球主要市场指数分析报告"
            elif "symbol" in query_data:
                return f"{query_data['symbol']} 加密货币分析报告"
        
        return "金融市场分析与投资建议报告"
    
    def _generate_summary(self, query_data, insights):
        """
        生成报告摘要
        参数:
            query_data: 查询数据
            insights: 深度洞察
        返回:
            报告摘要
        """
        summary = "本报告基于当前市场数据，提供全面的金融分析和个性化投资建议。"
        
        # 添加市场概览
        if "market_insights" in insights and "market_outlook" in insights["market_insights"]:
            market_outlook = insights["market_insights"]["market_outlook"]
            summary += f"\n\n市场概览：{market_outlook}"
        
        # 添加关键建议
        if "investment_suggestions" in insights and "general_advice" in insights["investment_suggestions"]:
            general_advice = insights["investment_suggestions"]["general_advice"]
            summary += f"\n\n核心建议：{general_advice}"
        
        return summary
    
    def _compile_market_analysis(self, query_data, analysis_results, insights):
        """
        编译市场分析部分
        参数:
            query_data: 查询数据
            analysis_results: 分析结果
            insights: 深度洞察
        返回:
            市场分析内容
        """
        market_analysis = {
            "market_trends": {},
            "sector_performance": {},
            "key_metrics": {},
            "technical_analysis": {}
        }
        
        # 添加市场趋势
        if "market_insights" in insights:
            market_analysis["market_trends"] = {
                "overall_outlook": insights["market_insights"].get("market_outlook", ""),
                "key_factors": insights["market_insights"].get("risk_factors", []),
                "sector_trends": insights["market_insights"].get("sector_trends", [])
            }
        
        # 添加技术分析
        if isinstance(analysis_results, dict):
            if "analysis" in analysis_results:
                market_analysis["technical_analysis"] = analysis_results["analysis"]
        
        # 添加关键指标
        if "market_insights" in insights and "key_metrics" in insights["market_insights"]:
            market_analysis["key_metrics"] = insights["market_insights"]["key_metrics"]
        
        return market_analysis
    
    def _compile_recommendations(self, insights, user_profile):
        """
        编译投资建议部分
        参数:
            insights: 深度洞察
            user_profile: 用户画像
        返回:
            投资建议内容
        """
        recommendations = {
            "personalized_advice": "",
            "asset_allocation": {},
            "sector_focus": [],
            "investment_strategy": {},
            "implementation_steps": []
        }
        
        # 获取风险偏好对应的问候语
        risk_greeting = {
            "conservative": "作为稳健型投资者",
            "balanced": "作为平衡型投资者",
            "aggressive": "作为进取型投资者"
        }
        
        # 生成个性化建议开头
        greeting = risk_greeting.get(user_profile.get("risk_profile", "balanced"), "作为投资者")
        recommendations["personalized_advice"] = f"{greeting}，我们建议您关注以下投资方向："
        
        # 添加资产配置
        if "portfolio_recommendations" in insights and "asset_allocation" in insights["portfolio_recommendations"]:
            recommendations["asset_allocation"] = insights["portfolio_recommendations"]["asset_allocation"]
        
        # 添加行业配置
        if "portfolio_recommendations" in insights and "sector_allocation" in insights["portfolio_recommendations"]:
            sectors = insights["portfolio_recommendations"]["sector_allocation"]
            # 转换为建议列表
            sector_list = [f"{sector}行业配置{percentage}%" for sector, percentage in sectors.items()]
            recommendations["sector_focus"] = sector_list
        
        # 添加投资策略
        if "investment_suggestions" in insights:
            suggestions = insights["investment_suggestions"]
            recommendations["investment_strategy"] = {
                "entry_exit": suggestions.get("entry_exit_strategy", ""),
                "timing": suggestions.get("timing", ""),
                "risk_management": suggestions.get("risk_management", [])
            }
        
        # 添加实施步骤
        recommendations["implementation_steps"] = [
            "评估当前投资组合状况",
            "根据建议调整资产配置比例",
            "选择合适的投资工具和产品",
            "设定投资目标和时间范围",
            "定期监控和再平衡投资组合"
        ]
        
        return recommendations
    
    def _generate_conclusion(self, insights, user_profile):
        """
        生成报告结论
        参数:
            insights: 深度洞察
            user_profile: 用户画像
        返回:
            报告结论
        """
        conclusion = "综上所述，当前市场环境下，我们建议您："
        
        # 根据风险偏好添加结论
        risk_profile = user_profile.get("risk_profile", "balanced")
        
        if risk_profile == "conservative":
            conclusion += "\n1. 保持谨慎态度，以保本为主"
            conclusion += "\n2. 优先配置高评级债券和稳定收益类产品"
            conclusion += "\n3. 小额参与优质蓝筹股，分散投资风险"
            conclusion += "\n4. 保持充足现金流动性，等待更好的投资机会"
        elif risk_profile == "balanced":
            conclusion += "\n1. 维持股债平衡的投资组合"
            conclusion += "\n2. 关注业绩稳定、估值合理的优质企业"
            conclusion += "\n3. 适当参与成长性行业的投资机会"
            conclusion += "\n4. 定期再平衡，控制单一资产风险"
        else:  # aggressive
            conclusion += "\n1. 把握市场结构性机会"
            conclusion += "\n2. 重点关注科技创新和高成长领域"
            conclusion += "\n3. 采用波段操作策略，提高资金利用效率"
            conclusion += "\n4. 设置严格止损，控制下行风险"
        
        conclusion += "\n\n投资有风险，入市需谨慎。本报告仅供参考，不构成任何投资建议。"
        
        return conclusion
    
    def _save_report(self, report_content):
        """
        保存报告为JSON文件
        参数:
            report_content: 报告内容
        返回:
            报告文件路径
        """
        report_filename = f"{report_content['report_id']}.json"
        report_path = os.path.join(self.report_dir, report_filename)
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report_content, f, ensure_ascii=False, indent=2)
        
        return report_path
    
    def _generate_html_report(self, report_content):
        """
        生成HTML格式报告
        参数:
            report_content: 报告内容
        返回:
            HTML报告内容
        """
        html = f"""
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>{report_content['title']}</title>
            <style>
                body {{
                    font-family: 'Microsoft YaHei', Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #f5f5f5;
                }}
                .container {{
                    background-color: white;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }}
                h1 {{
                    color: #2c3e50;
                    border-bottom: 2px solid #3498db;
                    padding-bottom: 10px;
                }}
                h2 {{
                    color: #2980b9;
                    margin-top: 30px;
                    border-left: 5px solid #3498db;
                    padding-left: 15px;
                }}
                h3 {{
                    color: #16a085;
                }}
                .meta-info {{
                    background-color: #ecf0f1;
                    padding: 15px;
                    border-radius: 5px;
                    margin-bottom: 20px;
                }}
                .summary {{
                    background-color: #e8f4fc;
                    padding: 20px;
                    border-radius: 5px;
                    margin-bottom: 30px;
                }}
                ul, ol {{
                    padding-left: 25px;
                }}
                li {{
                    margin-bottom: 8px;
                }}
                .highlight {{
                    background-color: #fff3cd;
                    padding: 15px;
                    border-radius: 5px;
                    border-left: 4px solid #ffc107;
                }}
                .risk-warning {{
                    background-color: #f8d7da;
                    color: #721c24;
                    padding: 15px;
                    border-radius: 5px;
                    margin-top: 30px;
                }}
                .table-container {{
                    overflow-x: auto;
                    margin: 20px 0;
                }}
                table {{
                    width: 100%;
                    border-collapse: collapse;
                }}
                th, td {{
                    padding: 12px;
                    text-align: left;
                    border-bottom: 1px solid #ddd;
                }}
                th {{
                    background-color: #f2f2f2;
                }}
                tr:hover {{
                    background-color: #f5f5f5;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>{report_content['title']}</h1>
                
                <div class="meta-info">
                    <p><strong>报告ID:</strong> {report_content['report_id']}</p>
                    <p><strong>生成时间:</strong> {report_content['generated_at']}</p>
                    <p><strong>用户风险偏好:</strong> {report_content['user_profile'].get('risk_profile', '未知')}</p>
                </div>
                
                <h2>摘要</h2>
                <div class="summary">
                    {report_content['executive_summary'].replace('\n', '<br>')}
                </div>
                
                <h2>市场分析</h2>
                
                <h3>市场趋势</h3>
                <p>{report_content['market_analysis'].get('market_trends', {}).get('overall_outlook', '')}</p>
                
                <h3>行业表现</h3>
                <ul>
        """
        
        # 添加行业趋势列表
        sector_trends = report_content['market_analysis'].get('market_trends', {}).get('sector_trends', [])
        for trend in sector_trends:
            html += f"<li>{trend}</li>"
        
        html += """
                </ul>
                
                <h3>关键风险因素</h3>
                <ul>
        """
        
        # 添加风险因素列表
        risk_factors = report_content['market_analysis'].get('market_trends', {}).get('key_factors', [])
        for factor in risk_factors:
            html += f"<li>{factor}</li>"
        
        html += """
                </ul>
                
                <h2>投资建议</h2>
                
                <div class="highlight">
                    <p>{report_content['investment_recommendations'].get('personalized_advice', '')}</p>
                </div>
                
                <h3>资产配置建议</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>资产类别</th>
                                <th>配置比例</th>
                            </tr>
                        </thead>
                        <tbody>
        """
        
        # 添加资产配置表格
        asset_allocation = report_content['investment_recommendations'].get('asset_allocation', {})
        for asset, percentage in asset_allocation.items():
            html += f"""
                            <tr>
                                <td>{asset}</td>
                                <td>{percentage}%</td>
                            </tr>
            """
        
        html += """
                        </tbody>
                    </table>
                </div>
                
                <h3>行业配置建议</h3>
                <ul>
        """
        
        # 添加行业配置建议
        sector_focus = report_content['investment_recommendations'].get('sector_focus', [])
        for focus in sector_focus:
            html += f"<li>{focus}</li>"
        
        html += """
                </ul>
                
                <h3>投资策略</h3>
                <p><strong>入场/出场策略:</strong> {report_content['investment_recommendations'].get('investment_strategy', {}).get('entry_exit', '')}</p>
                <p><strong>时机选择:</strong> {report_content['investment_recommendations'].get('investment_strategy', {}).get('timing', '')}</p>
                
                <h3>风险管理建议</h3>
                <ul>
        """
        
        # 添加风险管理建议
        risk_management = report_content['investment_recommendations'].get('investment_strategy', {}).get('risk_management', [])
        for item in risk_management:
            html += f"<li>{item}</li>"
        
        html += """
                </ul>
                
                <h3>实施步骤</h3>
                <ol>
        """
        
        # 添加实施步骤
        steps = report_content['investment_recommendations'].get('implementation_steps', [])
        for step in steps:
            html += f"<li>{step}</li>"
        
        html += """
                </ol>
                
                <h2>风险评估</h2>
                <p><strong>市场风险水平:</strong> {report_content['risk_assessment'].get('market_risk_level', '未知')}</p>
                <p><strong>建议仓位控制:</strong> {report_content['risk_assessment'].get('recommended_position_size', '未知')}</p>
                
                <h2>结论</h2>
                <p>{report_content['conclusion'].replace('\n', '<br>')}</p>
                
                <div class="risk-warning">
                    <strong>风险提示:</strong> 本报告基于公开信息编制，仅供参考，不构成任何投资建议。投资有风险，入市需谨慎。
                </div>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _save_html_report(self, html_content, report_id):
        """
        保存HTML报告
        参数:
            html_content: HTML内容
            report_id: 报告ID
        返回:
            HTML文件路径
        """
        html_filename = f"{report_id}.html"
        html_path = os.path.join(self.report_dir, html_filename)
        
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return html_path
    
    def _format_report_for_display(self, report_content):
        """
        格式化报告用于显示
        参数:
            report_content: 报告内容
        返回:
            格式化的报告文本
        """
        formatted = f"# {report_content['title']}\n\n"
        formatted += f"**报告ID:** {report_content['report_id']}\n"
        formatted += f"**生成时间:** {report_content['generated_at']}\n\n"
        
        formatted += "## 摘要\n"
        formatted += f"{report_content['executive_summary']}\n\n"
        
        formatted += "## 市场分析\n"
        formatted += f"**市场趋势:** {report_content['market_analysis'].get('market_trends', {}).get('overall_outlook', '')}\n\n"
        
        formatted += "**行业趋势:**\n"
        for trend in report_content['market_analysis'].get('market_trends', {}).get('sector_trends', []):
            formatted += f"- {trend}\n"
        formatted += "\n"
        
        formatted += "## 投资建议\n"
        formatted += f"**个性化建议:** {report_content['investment_recommendations'].get('personalized_advice', '')}\n\n"
        
        formatted += "**资产配置建议:**\n"
        for asset, percentage in report_content['investment_recommendations'].get('asset_allocation', {}).items():
            formatted += f"- {asset}: {percentage}%\n"
        formatted += "\n"
        
        formatted += "## 结论\n"
        formatted += report_content['conclusion']
        
        return formatted